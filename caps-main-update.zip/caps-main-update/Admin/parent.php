<?php
session_start(); // Start the session
include 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information from the session
$fullname = $_SESSION['fullname'];
$role = $_SESSION['role'];
$user_id = $_SESSION['id']; // Get the logged-in user's ID

$sql = "SELECT profile_image FROM admin_staff WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user ID to the query
$stmt->execute();
$stmt->bind_result($profile_image);
$stmt->fetch();
$stmt->close();

// If the profile image is empty, you can use a default image
if (empty($profile_image)) {
    $profile_image = 'path/to/default-image.jpg'; // Provide the path to a default image
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    
    <title>Parent Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/parent.css" rel="stylesheet" />

</head>
<body>

<div class="sidebar">
        <img src="logo/logo/logo.png" alt="Logo">
        <a href="attendance.php">
            <i class="fas fa-calendar-check"></i> Attendance
        </a>
        <a href="student.php">
            <i class="fas fa-user-graduate"></i> Student Records
        </a>
        <a href="parent.php" class="active">
            <i class="fas fa-users"></i> Parent Records
        </a>
        <a href="staff.php">
            <i class="fas fa-user-tie"></i> Admin/Staff Records
        </a>
        <a href="pick_up_records.php">
            <i class="fas fa-clipboard-list"></i> Pick-Up Records
        </a>
        <a href="events.php">
            <i class="fas fa-calendar-alt"></i> Events
        </a>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
    <div class="header">
        <div class="user-info">
            <div class="notification">
                <i class="fas fa-bell"></i>
            </div>
            <div class="vertical-rule"></div>
            <div class="profile">
                <!-- Dynamically display the profile image -->
                <?php if (empty($profile_image)) : ?>
                    <img alt="User profile picture" height="40" src="<?php echo htmlspecialchars($profile_image); ?>" width="40"/>
                <?php else: ?>
                    <img alt="User profile picture" height="40" src="data:image/jpeg;base64,<?php echo base64_encode($profile_image); ?>" width="40"/>
                <?php endif; ?>
                <div class="profile-text">
                    <span><?php echo htmlspecialchars($_SESSION['role']); ?></span><br>
                    <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                </div>
            </div>
        </div>
    </div>

    <hr/>
        <div class="table-container">
        <div class="search-bar-container">
        <button class="create-btn" id="create-btn">CREATE</button>
<!-- Parent form modal and Authorized Info form -->
 
<div class="overlay" id="overlay">

    <div class="create-panel" id="create-panel">
        <button class="close-btn" id="close-btn">&times;</button>
        <form id="parent-form" action="submit_form.php" method="post" enctype="multipart/form-data">
            <h2>Parent Account Creation</h2>
            <!-- Form Fields -->
            <label for="fullname">Full Name:</label>
            <input type="text" id="fullname" name="fullname" required>
            <label for="contactnumber">Contact Number:</label>
            <input type="tel" id="contactnumber" name="contact_number" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <label for="parentimage">Parent's Image:</label>
            <input type="file" id="parentimage" name="parent_image" accept="image/*" required>
            <button type="submit">Submit</button>
        </form>
    </div>

    <!-- Authorized Info Form -->
    <div id="authorized-info" class="authorized-info hidden">
        <form id="authorized-form" action="authorized_submit_form.php" method="post" enctype="multipart/form-data">
            <h3>Authorized Pick-Up Person</h3>
            <!-- Form Fields -->
            <label for="authorized_fullname">Full Name:</label>
            <input type="text" id="authorized_fullname" name="authorized_fullname" required>

            <label for="authorized_address">Address:</label>
            <input type="text" id="authorized_address" name="authorized_address" required>

            <label for="authorized_age">Age:</label>
            <input type="number" id="authorized_age" name="authorized_age" required>

            <label for="authorized_image">Upload Authorized Image:</label>
            <input type="file" id="authorized_image" name="authorized_image" accept="image/*" required>

            <button type="submit">Submit Authorized Pick-Up</button>
        </form>
    </div>
</div>
<script>
// Show the loader
function showLoader() {
    document.getElementById('loader').style.display = 'flex'; // Ensure loader exists
}

// Hide the loader
function hideLoader() {
    document.getElementById('loader').style.display = 'none'; // Ensure loader is hidden properly
}

// Event listener for "CREATE" button
document.getElementById('create-btn').addEventListener('click', function() {
    document.getElementById('overlay').style.display = 'block';
    document.getElementById('create-panel').classList.add('show');
});

// Event listener for "CLOSE" button
document.getElementById('close-btn').addEventListener('click', function() {
    document.getElementById('overlay').style.display = 'none';
    document.getElementById('create-panel').classList.remove('show');
    document.getElementById('parent-form').reset();
});

// Handle Parent Form Submission
document.getElementById('parent-form').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent default form submission

    showLoader(); // Show loader while processing

    const formData = new FormData(this); // Collect form data

    try {
        const response = await fetch('submit_form.php', {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json(); // Parse JSON response
        console.log(data); // Add console log for debugging

        if (data.success) {
            // Successfully created the parent account
            alert(data.message || 'Parent account created successfully.');

            // Hide the Parent Form modal
            document.getElementById('create-panel').classList.remove('show');
            document.getElementById('overlay').style.display = 'none';  // Hide overlay

            // Reset the parent form
            this.reset();

            // Show the Authorized Info Form
            const authorizedInfo = document.getElementById('authorized-info');
            const overlay = document.getElementById('overlay');

            // Ensure the form and overlay are visible
            if (authorizedInfo) {
                authorizedInfo.classList.remove('hidden'); // Remove hidden class
                authorizedInfo.style.display = 'block'; // Ensure it's shown correctly
                console.log('Authorized Info Form should be visible now.');
            } else {
                console.error('Authorized Info Form not found!');
            }

            if (overlay) {
                overlay.style.display = 'block'; // Show the overlay
                console.log('Overlay should be visible now.');
            } else {
                console.error('Overlay not found!');
            }

            // Append the Parent ID to the Authorized Info Form as a hidden field
            const parentIdInput = document.createElement('input');
            parentIdInput.type = 'hidden';
            parentIdInput.name = 'parent_id';
            parentIdInput.value = data.parent_id;
            document.getElementById('authorized-form').appendChild(parentIdInput);

            // Scroll to the Authorized Info Form (optional)
            authorizedInfo.scrollIntoView({ behavior: 'smooth' });

        } else {
            alert(data.message || 'An error occurred while creating the parent account.');
            // Redirect to parent PHP page if parent creation failed
            window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to create parent account. Please try again.');
        // Redirect to parent PHP page if there was an error in the parent form submission
        window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
    } finally {
        hideLoader(); // Hide loader
    }
});

// Handle Authorized Info Form Submission (Assuming similar structure)
document.getElementById('authorized-form').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent default form submission

    showLoader(); // Show loader while processing

    const formData = new FormData(this); // Collect form data

    try {
        const response = await fetch('authorized_submit_form.php', {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json(); // Parse JSON response
        console.log(data); // Add console log for debugging

        if (data.success) {
            // Successfully created the authorized info
            alert(data.message || 'Authorized person info saved successfully.');

            // Redirect to the parent PHP page after successful authorized info submission
            window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
        } else {
            alert(data.message || 'An error occurred while saving authorized person info.');
            // Redirect to parent PHP page if the authorized person creation failed
            window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to save authorized person info. Please try again.');
        // Redirect to parent PHP page if there was an error in the authorized info submission
        window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
    } finally {
        hideLoader(); // Hide loader
    }
});
</script>



            <div class="search-bar">
            <input type="text" id="search" placeholder="Search..." onkeyup="performSearch(event)">
            </div>
        </div>
        <?php
include 'connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination variables
$itemsPerPage = 10; // Items per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page from the URL
$currentPage = max(1, $currentPage); // Ensure current page is at least 1
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for SQL query

$userRole = $_SESSION['role']; 

// Prepare the query for pagination
$stmt = $conn->prepare("SELECT id, fullname, contact_number, email, address FROM parent_acc LIMIT ?, ?");
$stmt->bind_param("ii", $offset, $itemsPerPage);
$stmt->execute();
$result = $stmt->get_result();

// Count total records for pagination
$totalResult = $conn->query("SELECT COUNT(*) as total FROM parent_acc");
$totalRow = $totalResult->fetch_assoc();
$totalItems = $totalRow['total'];
$totalPages = ceil($totalItems / $itemsPerPage); // Calculate total pages

// HTML Table
echo '<table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Contact Number</th>
                <th>Email Address</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>' . htmlspecialchars($row['fullname']) . '</td>
                <td>' . htmlspecialchars($row['contact_number']) . '</td>
                <td>' . htmlspecialchars($row['email']) . '</td>
                <td>' . htmlspecialchars($row['address']) . '</td>
                <td>';

        // Check if the user is a super admin
        if ($userRole === 'Super Admin') {
            echo '<i class="fas fa-pen" title="Edit" onclick="openEditModal(' . $row['id'] . ', \'' . htmlspecialchars($row['fullname']) . '\', \'' . htmlspecialchars($row['contact_number']) . '\', \'' . htmlspecialchars($row['email']) . '\', \'' . htmlspecialchars($row['address']) . '\')"></i>
                  <i class="fas fa-trash" title="Delete" onclick="location.href=\'delete_staff.php?id=' . $row['id'] . '\'"></i>';
        }

        // Always show the View button
        echo '<i class="fas fa-eye" title="View" data-parent-id="' . $row['id'] . '" onclick="showChildInfo(this.dataset.parentId)"></i>';
        
        echo '</td>
              </tr>';
    }
} else {
    echo '<tr><td colspan="5">No records found</td></tr>';
}

echo '  </tbody>
      </table>';



// Close the database connection
$stmt->close();
$conn->close();
?>
<!-- Combined Modals -->
<div id="edit-overlay" class="modal-edit" style="display: none;">
    <div class="modal-contentss">
        <span class="close" id="edit-close-btn">&times;</span>
        <h2>Edit User Information</h2>
        <form id="edit-form" action="edit_user.php" method="post">
            <input type="hidden" id="edit_user_id" name="user_id">
            <div class="form-group">
                <label for="edit_fullname">Full Name:</label>
                <input type="text" id="edit_fullname" name="fullname" required>
            </div>
            <div class="form-group">
                <label for="edit_contactnumber">Contact Number:</label>
                <input type="tel" id="edit_contactnumber" name="contact_number" required>
            </div>
            <div class="form-group">
                <label for="edit_email">Email:</label>
                <input type="email" id="edit_email" name="email" required>
            </div>
            <div class="form-group">
                <label for="edit_address">Address:</label>
                <input type="text" id="edit_address" name="address" required>
            </div>
            <div class="form-group">
                <label for="edit_password">Password:</label>
                <input type="password" id="edit_password" name="password">
            </div>
            <div class="form-group">
                <label for="edit_confirm_password">Confirm Password:</label>
                <input type="password" id="edit_confirm_password" name="confirm_password">
            </div>
            <button type="submit" class="submit-btn">Update</button>
        </form>
    </div>
</div>

<div id="childInfoModal" class="modal-edit" style="display: none;">
    <div class="modal-contentss">
        <span class="close" onclick="closeModal()">&times;</span>
        <h3>Student Information</h3>
        <div class="student-info">
            <!-- Dynamic Student Info -->
        </div>
    </div>
</div>

<!-- Enhanced Styles -->
<style>
/* Reuse existing styles and enhance */
.modal-edit {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(5px);
    animation: fade-in 0.3s ease-in-out;
}
.modal-contentss {
    background-color: #f9f9f9;
    margin: 5% auto;
    padding: 30px;
    width: 90%;
    max-width: 600px;
    border-radius: 12px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
    animation: slide-in 0.3s ease-out;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: #333;
    position: relative;
    overflow: hidden;
}
.close {
    color: #888;
    position: absolute;
    right: 15px;
    top: 15px;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s;
}
.close:hover {
    color: #ff6b6b;
}
h2, h3 {
    font-size: 24px;
    font-weight: bold;
    text-align: center;
    color: #2c3e50;
    margin-bottom: 20px;
    border-bottom: 2px solid #e5e5e5;
    padding-bottom: 10px;
}
.form-group {
    margin-bottom: 20px;
}
.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
    color: #555;
    font-size: 14px;
}
.form-group input,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 14px;
    background-color: #fff;
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
}
.form-group input:focus,
.form-group textarea:focus {
    border-color: #007bff;
    outline: none;
    box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
}
.submit-btn {
    background: linear-gradient(to right, #3498db, #2980b9);
    color: #fff;
    border: none;
    padding: 12px;
    font-size: 16px;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    width: 100%;
    margin-top: 15px;
    transition: background 0.3s, transform 0.2s;
}
.submit-btn:hover {
    background: linear-gradient(to right, #2980b9, #3498db);
    transform: translateY(-2px);
}
.submit-btn:active {
    transform: translateY(0);
}
@keyframes fade-in {
    from { opacity: 0; }
    to { opacity: 1; }
}
@keyframes slide-in {
    from {
        transform: translateY(-20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}
</style>

<!-- Scripts (merged functionalities) -->
<script>
// Open Edit Modal for User
// Open Edit Modal for User
function openEditModal(userId, fullname, contactNumber, email, address) {
    document.getElementById('edit_user_id').value = userId;
    document.getElementById('edit_fullname').value = fullname;
    document.getElementById('edit_contactnumber').value = contactNumber;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_address').value = address;

    document.getElementById('edit-overlay').style.display = 'block';
}

// Close Edit Modal
document.getElementById('edit-close-btn').addEventListener('click', function () {
    document.getElementById('edit-overlay').style.display = 'none';
    document.getElementById('edit-form').reset();
});

// Close on Outside Click
window.onclick = function (event) {
    const modal = document.getElementById('edit-overlay');
    if (event.target === modal) {
        modal.style.display = 'none';
        document.getElementById('edit-form').reset();
    }
};

// Handle Edit Form Submission
async function handleEditFormSubmission(event) {
    event.preventDefault(); // Prevent default form submission

    const form = event.target; // Get the form element
    const formData = new FormData(form); // Prepare form data for submission

    try {
        const response = await fetch(form.action, {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            // Handle HTTP errors (e.g., 404, 500)
            throw new Error(`HTTP Error: ${response.status}`);
        }

        const data = await response.json(); // Parse JSON response

        if (data.success) {
            // Show success message and reload the page
            alert(data.message || 'Information updated successfully.');
            window.location.reload();
        } else {
            // Show server-side validation error message
            alert(data.message || 'An error occurred while updating information.');
        }
    } catch (error) {
        // Log and show network or unexpected errors
        console.error('Error:', error.message);
        alert('Failed to update information.');
    }
}

// Attach submit handler to the edit form
document.getElementById('edit-form').addEventListener('submit', handleEditFormSubmission);

// Open Child Info Modal
function openModal() {
    const modal = document.getElementById('childInfoModal');
    modal.style.display = 'block'; // Display the modal
}

// Close Child Info Modal
function closeModal() {
    const modal = document.getElementById('childInfoModal');
    modal.style.display = 'none'; // Hide the modal
}


// Event listener for outside click
window.onclick = function(event) {
    const modal = document.getElementById('childInfoModal');
    if (event.target === modal) {
        closeModal();
    }
};

// Debug fetch example
function showChildInfo(parentId) {
    console.log('Fetching data for parent ID:', parentId);
    fetch(`child_info.php?parent_id=${parentId}`)
        .then(response => response.text())
        .then(html => {
            const container = document.querySelector('.student-info');
            container.innerHTML = html || '<p>No data available</p>';
            openModal();
        })
        .catch(err => {
            console.error('Error fetching child info:', err);
            alert('Failed to load child information.');
        });
}


</script>


            <div class="pagination" id="pagination"></div>
    <script>
        const totalItems = <?php echo $totalItems; ?>; 
        const itemsPerPage = <?php echo $itemsPerPage; ?>; 
        let currentPage = <?php echo $currentPage; ?>; 

        function renderPagination() {
            const pagination = document.getElementById('pagination');
            pagination.innerHTML = ''; // Clear previous pagination

            const totalPages = Math.ceil(totalItems / itemsPerPage);

            // Previous button
            const prevLink = document.createElement('a');
            prevLink.innerHTML = '«';
            prevLink.className = currentPage === 1 ? 'disabled' : '';
            prevLink.onclick = function() {
                if (currentPage > 1) {
                    currentPage--;
                    updatePage();
                }
            };
            pagination.appendChild(prevLink);

            // Page numbers
            for (let i = 1; i <= totalPages; i++) {
                const pageNumber = document.createElement('div');
                pageNumber.innerHTML = i;
                pageNumber.className = `page-number ${i === currentPage ? 'active' : ''}`;
                pageNumber.onclick = function() {
                    currentPage = i;
                    updatePage();
                };
                pagination.appendChild(pageNumber);
            }

            // Next button
            const nextLink = document.createElement('a');
            nextLink.innerHTML = '»';
            nextLink.className = currentPage === totalPages ? 'disabled' : '';
            nextLink.onclick = function() {
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePage();
                }
            };
            pagination.appendChild(nextLink);
        }

        function updatePage() {
            window.location.href = '?page=' + currentPage; // Redirect to the correct page
        }

        // Initial rendering
        renderPagination();
    </script>
            </div>
        </div>
    </div>

    <script src="script/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<!-- Loading Spinner -->
<div id="loader" class="loader" style="display: none;">
    <div class="spinner"></div>
</div>
</body>
</html>
