<html>
<head>
    <title>Pick-Up Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet"/>
    <link href="style.css" rel="stylesheet">
</head>
<body>
    <div class="sidebar">
        <div>
            <div class="logo"><img src="pic/logo.png" alt="Image" width="100" height="100"></div>
            <div class="menu-item">QR Code Scan</div>
            <div class="menu-item"><a href="S_records.php">Student Records</a></div>
            <div class="menu-item"><a href="P_records.php">Parent Records</a></div>
            <div class="menu-item"><a href="U_records.php">Pick-Up Records</a></div>
        </div>
            <div class="bottom-menu">
                <div class="menu-item"><i class="fas fa-cog"></i>Settings</div>
                <div class="menu-item"><i class="fas fa-sign-out-alt"></i>Logout</div>
            </div>
    </div>
    <div class="main-content">
        <div class="header">
            <div class="search-bar">
                <i class="fas fa-filter"></i>
                <input type="text" placeholder="Search"/>
                <i class="fas fa-search"></i>
            </div>
            <div class="user-info">
                <img src="https://oaidalleapiprodscus.blob.core.windows.net/private/org-RcpoXHkzChYnDbFAyeQ8tamr/user-ehrvabJ3DufsCu8YJ7PqY5gl/img-8ZChGx7jNJA259IrPVxRYd7R.png?st=2024-09-26T08%3A53%3A56Z&se=2024-09-26T10%3A53%3A56Z&sp=r&sv=2024-08-04&sr=b&rscd=inline&rsct=image/png&skoid=d505667d-d6c1-4a0a-bac7-5c84a87759f8&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2024-09-25T23%3A15%3A49Z&ske=2024-09-26T23%3A15%3A49Z&sks=b&skv=2024-08-04&sig=gm4ygCgKN0ZjRNxD0j%2B7uzbrz0ZFy7rtrTKHAksQCXc%3D" alt="User profile picture" width="40" height="40"/>
                <div class="user-name">
                    <div>STAFF</div>
                    <div>STAFF</div>
                </div>
            </div>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Student Name</th>
                        <th>Grade & Section</th>
                        <th>Pick-up Information</th>
                        <th>Confirmation</th>
                        <th>Time</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <form action="U_records.php" method="POST"></form>
                </tbody>
            </table>
            <div class="pagination">
                <div class="page-item">
                    <a href="#">Prev</a>
                    <a href="#">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">4</a>
                    <a href="#">5</a>
                    <a href="#">Next</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>